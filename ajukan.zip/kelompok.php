<?php
require_once '../config/database.php';
require_once '../config/helpers.php';

setCORSHeaders();

$conn = getConnection();
$result = $conn->query(
    "SELECT id, nama_kelompok, desa
     FROM kelompok
     WHERE status = 'aktif'
     ORDER BY nama_kelompok ASC"
);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

sendResponse(true, 'OK', $data);
$conn->close();